import React, { useState, useEffect } from "react";
import axios from "axios";

function RegisterForm() {
  const [formData, setFormData] = useState({
    id: "",
    username: "",
    password: "",
  });

  const [data, setData] = useState([]);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post(
        "http://localhost:3002/register",
        formData
      );
      console.log(response.data);
      alert("Data inserted");
      handleGetData();
    } catch (error) {
      console.error(error);
    }
  };

  const handleGetData = async () => {
    try {
      const response = await axios.get("http://localhost:3002/get");
      setData(response.data.result); // Set data to response.data.result
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    handleGetData();
  }, []);

  return (
    <>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          name="id"
          placeholder="ID"
          value={formData.id}
          onChange={handleChange}
        />
        <input
          type="text"
          name="username"
          placeholder="Username"
          value={formData.username}
          onChange={handleChange}
        />
        <input
          type="password"
          name="password"
          placeholder="Password"
          value={formData.password}
          onChange={handleChange}
        />
        <button type="submit">Register</button>
      </form>
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Username</th>
            <th>Password</th>
          </tr>
        </thead>
        <tbody>
          {data.map((value, index) => (
            <tr key={index}>
              <td>{value.id}</td>
              <td>{value.username}</td>
              <td>{value.password}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  );
}

export default RegisterForm;
