const express = require("express");
const cors = require("cors");
const mycon = require("mysql2");
const bodyParser = require("body-parser");

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static("public"));

const c = mycon.createConnection({
  host: "localhost",
  port: 3306,
  user: "root",
  database: "crud_task",
  password: "Udhaya@1",
});

c.connect(function (error) {
  if (error) {
    console.log(error);
  } else {
    console.log("database connected Sucessfully");
  }
});

app.post("/register", (req, res) => {
  const { id, username, password } = req.body;

  let sql = "INSERT INTO tasks (id,username,password) VALUES (?,?,?)";

  c.query(sql, [id, username, password], (error, result) => {
    if (error) {
      console.log(error);
      res.status(500).json({ error: "faild to register" });
    } else {
      res.status(200).json({ result: "success" });
    }
  });
});

app.get("/get", (req, res) => {
 
  let sql = "SELECT * FROM tasks";
  c.query(sql, (error, result) => {
    if (error) {
      console.log(error);
      res.status(500).json({ error: "faild to register" });
    } else {
      res.status(200).json({ result: "success1",result });
    }
  });
});


app.delete("/del/:id", (req, res) => {
    const id = req.params.id;
  
    let sql = "DELETE FROM tasks WHERE ID=?";
    c.query(sql, [id], (error, result) => {
      if (error) {
        console.log(error);
        res.status(500).json({ error: "failed to delete" });
      } else {
        res.status(200).json({ result: "successfully deleted" });
      }
    });
  });

  app.put("/update/:id",(req,res)=>{
    const id=req.params.id;
    const {username,password}=req.body;
    let sql="UPDATE tasks SET username=?,password=? WHERE id=?";
    c.query(sql,[username,password,id,],(error,result)=>{
        if(error){
            console.log(error);
            res.status(500).json({ error: "failed to update" });
        }
        else {
            res.status(200).json({ result: "successfully updated" });
          }
    })
  })


app.listen(3002, () => {
  console.log("running on 3002");
});
